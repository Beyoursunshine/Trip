package com.zhiyou.bd17.bi;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.support.SpringBootServletInitializer;

/**
 * Created by ThinkPad on 2017/12/6.
 */
@SpringBootApplication
@MapperScan("com.zhiyou.bd17.bi.dao")
public class BIApplication extends SpringBootServletInitializer{
    public static void main(String[] args){
        SpringApplication.run(BIApplication.class);
    }
}
