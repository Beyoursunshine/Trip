package com.zhiyou.bd17.bi.service;

import com.zhiyou.bd17.bi.domain.HotelRoomTypeRate;

import java.util.List;

/**
 * Created by ThinkPad on 2017/12/6.
 */
public interface HotelRoomTypeRateService {
    public List<HotelRoomTypeRate> findAll();
}
