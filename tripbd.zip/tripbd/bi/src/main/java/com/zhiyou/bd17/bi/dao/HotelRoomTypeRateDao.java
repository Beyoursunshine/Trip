package com.zhiyou.bd17.bi.dao;

import com.zhiyou.bd17.bi.domain.HotelRoomTypeRate;

import java.util.List;

/**
 * Created by ThinkPad on 2017/12/6.
 */
public interface HotelRoomTypeRateDao {
    public List<HotelRoomTypeRate> findAll();
}
