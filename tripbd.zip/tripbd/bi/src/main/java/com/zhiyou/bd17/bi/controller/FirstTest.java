package com.zhiyou.bd17.bi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by ThinkPad on 2017/12/6.
 */
@Controller
public class FirstTest {
    @RequestMapping("/hello")
    public String helloPage(Model model){
        model.addAttribute("dataFromBack","后台传来的数据");
        return "hello";
    }
}
