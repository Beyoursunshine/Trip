package com.zhiyou.bd17.bi.service.impl;

import com.zhiyou.bd17.bi.dao.HotelRoomTypeRateDao;
import com.zhiyou.bd17.bi.domain.HotelRoomTypeRate;
import com.zhiyou.bd17.bi.service.HotelRoomTypeRateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by ThinkPad on 2017/12/6.
 */
@Service
public class HotelRoomTypeRateServiceImpl implements HotelRoomTypeRateService{
    @Autowired
    private HotelRoomTypeRateDao hotelRoomTypeRateDao;

    public List<HotelRoomTypeRate> findAll() {
        return hotelRoomTypeRateDao.findAll();
    }
}
