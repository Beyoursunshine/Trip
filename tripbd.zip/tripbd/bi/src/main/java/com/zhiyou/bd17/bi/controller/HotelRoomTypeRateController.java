package com.zhiyou.bd17.bi.controller;

import com.zhiyou.bd17.bi.domain.HotelRoomTypeRate;
import com.zhiyou.bd17.bi.service.HotelRoomTypeRateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

/**
 * Created by ThinkPad on 2017/12/6.
 */
@Controller
public class HotelRoomTypeRateController {
    @Autowired
    private HotelRoomTypeRateService hotelRoomTypeRateService;

    @RequestMapping("/hotelrtrate")
    public String getHotelData(Model model){
        List<HotelRoomTypeRate> list = hotelRoomTypeRateService.findAll();
        model.addAttribute("hotelrtInfos",list);
        String labels = "";
        String roomNums = "";
        String bookNums = "";
        String checkInNums = "";
        for(int i=0;i<list.size();i++){
            HotelRoomTypeRate hotelRoomTypeRate = list.get(i);
            if(i==0){
                labels += "['"+hotelRoomTypeRate.getRoomtypeName()+"'";
                roomNums += "["+hotelRoomTypeRate.getRoomNum();
                bookNums += "["+hotelRoomTypeRate.getBookNum();
                checkInNums += "["+hotelRoomTypeRate.getCheckinNum();
            }else{
                labels += ",'"+hotelRoomTypeRate.getRoomtypeName()+"'";
                roomNums += ","+hotelRoomTypeRate.getRoomNum();
                bookNums += ","+hotelRoomTypeRate.getBookNum();
                checkInNums += ","+hotelRoomTypeRate.getCheckinNum();
            }
            if(i == list.size()-1){
                labels += "]";
                roomNums += "]";
                bookNums += "]";
                checkInNums += "]";
            }
        }
        model.addAttribute("labels",labels);
        model.addAttribute("roomNums",roomNums);
        model.addAttribute("bookNums",bookNums);
        model.addAttribute("checkInNums",checkInNums);
        return "hotelrtrate";
    }
}
