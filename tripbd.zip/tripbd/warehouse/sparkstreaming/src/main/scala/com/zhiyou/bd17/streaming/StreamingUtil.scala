package com.zhiyou.bd17.streaming

import org.apache.spark.SparkConf
import org.apache.spark.streaming.kafka010.{ConsumerStrategies, KafkaUtils, LocationStrategies}
import org.apache.spark.streaming.{Duration, StreamingContext}

/**
  * Created by ThinkPad on 2017/12/5.
  */
object StreamingUtil {
  val conf = new SparkConf().setAppName("streaming").setMaster("local[*]")
  val ssc = new StreamingContext(conf,Duration(10000))
  ssc.checkpoint("/btripcheckpoint")
  def getStreamingFromKafka(topics:Array[String]) = {
    //kafka的consumer配置信息
    val kafkaParams = Map[String,String](
      "bootstrap.servers" -> "centos1:9092,centos2:9092,centos3:9093,centos3:9092",
      "key.deserializer" -> "org.apache.kafka.common.serialization.StringDeserializer",
      "value.deserializer" -> "org.apache.kafka.common.serialization.StringDeserializer",
      "group.id" -> "use_a_separate_group_id_for_each_stream1",
      "auto.offset.reset" -> "latest",
      "enable.auto.commit" -> "false"
    )
    KafkaUtils.createDirectStream(ssc,LocationStrategies.PreferConsistent
      ,ConsumerStrategies.Subscribe[String,String](topics,kafkaParams))
  }
}
