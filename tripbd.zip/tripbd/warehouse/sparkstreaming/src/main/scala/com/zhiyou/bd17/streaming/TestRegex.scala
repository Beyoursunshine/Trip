package com.zhiyou.bd17.streaming

/**
  * Created by ThinkPad on 2017/12/5.
  */
object TestRegex {
  def main(args: Array[String]): Unit = {
    val regex = "JudgeNote\\((.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*)\\)".r
    val string = "JudgeNote(1,艺龙,22,用户姓名22,高级,14,0,title,2.0,5.0,4.0,3.0,2.0,7月入住,1,评论内容)"
    string match{
      case regex(hotelId,platform,userId,userName,userLevel,judgeTimes,coverCity,title,scoreSum,scoreDtl1,scoreDtl2,scoreDtl3,scoreDtl4
      ,liveDate,isPlateformOrdered,content) => println(content)
    }
  }
}
