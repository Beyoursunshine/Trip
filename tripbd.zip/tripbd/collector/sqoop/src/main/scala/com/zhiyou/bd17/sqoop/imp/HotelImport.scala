package com.zhiyou.bd17.sqoop.imp

/**
  * Created by ThinkPad on 2017/12/2.
  */
object HotelImport {

}
