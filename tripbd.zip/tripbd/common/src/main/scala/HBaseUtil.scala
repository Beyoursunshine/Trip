/**
  * Created by ThinkPad on 2017/11/30.
  */
object HBaseUtil {

}
